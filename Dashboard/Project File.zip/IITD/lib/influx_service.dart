import 'dart:convert';

import 'package:influxdb_client/api.dart';
import 'package:iitd/LandingPage/Meter1.dart';

class InfluxService {
  late InfluxDBClient client;
  late QueryService queryService;
  List<HistoryData1> history = [];
  InfluxService() {
    client = InfluxDBClient(
        url: 'http://10.17.51.12:8086',
        token:
            'gD5kuHNGXz9MGzeRlJ7MGT0wPa7bNlLQ8eS8giLyqx1wXURon3ZWQ1DfyTdJ8asm1WDvgiEYgjvvhH2sZDD9pw==',
        org: 'IIT-Delhi',
        bucket: 'iitdenergy',
        debug: true);
    queryService = client.getQueryService();
  }

  Future<void> getInfluxData(String time, String sensorId) async {
    String query = '''
from(bucket: "iitdenergy")
    |> range(start: -$time)
    |> filter(fn: (r) => r["_measurement"] == "mqtt_consumer")
    |> filter(fn: (r) => r["_field"] == "I1" or r["_field"] == "I2" or r["_field"] == "I3" or r["_field"] == "V1N" or r["_field"] == "V2N" or r["_field"] == "V3N")
    |> filter(fn: (r) => r["topic"] == "/devices/swsn/FSM-$sensorId")
    |> filter(fn: (r) => r["host"] == "baadalvm")
    |> pivot(rowKey:["_time"], columnKey: ["_field"], valueColumn: "_value")
    |> yield(name: "results")
''';

    var recordStream = await queryService.query(query);
    var recordList = await recordStream.toList();

      history = recordList.map((record) => HistoryData1(
        date: record['_time'],
        time: record['_time'],
        i1: record['I1'],
        i2: record['I2'],
        i3: record['I3'],
        v1: record['V1N'],
        v2: record['V2N'],
        v3: record['V3N'],
      )).toList();
  }

}